from __future__ import print_function
import signal
import copy
import sys
import time
from random import randint

#	dummy class created for alarmexception


class AlarmException(Exception):  # class of alarmexception
    pass
